import "./CartItem.scss";
const CartItem = () => {
    return <div>Cart item</div>;
};

export default CartItem;
