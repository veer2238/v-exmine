import "./Category.scss";
import Products from '../Products/Products'
const Category = () => {
    return <div >
        category

   
    
    </div>;
};

export default Category;
