import "./Footer.scss";
import { FaLocationArrow,FaMobileAlt,FaEnvelope } from "react-icons/fa";
import Payment from "../../assets/payments.png"




const Footer = () => {
    return <div>
        footer
   
     


      
    </div>


    
};

export default Footer;
