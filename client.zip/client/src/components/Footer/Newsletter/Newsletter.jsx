import "./Newsletter.scss";


const Newsletter = () => {
    return <div >
 newslatter
    </div>;
};

export default Newsletter;
