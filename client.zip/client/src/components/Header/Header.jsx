import "./Header.scss";
import { useEffect,useState,useContext } from "react";
import {useNavigate} from "react-router-dom";
import {AiOutlineHeart, AiOutlineSearch} from  "react-icons/ai";
import {FiPhoneCall,FiUser} from "react-icons/fi"
import {RiServiceFill} from "react-icons/ri"
import {AiOutlineMenuUnfold} from "react-icons/ai"
import {MdOutlineNotificationsNone} from "react-icons/md"
import Search from "./Search/Search";
import Cart from "../Cart/Cart";
import { Context } from "../../utils/Context";
import { icons } from "react-icons";
const Header = () => {
    const [scrolled,setScrolled] = useState(false)

    const HandleScroll = () =>{
        
        const offset = window.scrollY
        if (offset>200){
            setScrolled(true);

        }else{
            setScrolled(false);
        }
       
    }



    useEffect(()=>{
        window.addEventListener("scroll",HandleScroll)
        

    },[])
    return (
        <header className={`main-header ${scrolled ? 'sticky-header' : ""}`}>
            <div className="header-content">
                <ul className="left">
                    <div className="icon-part">
                    <FiPhoneCall/> 
                   <li> Contact</li>
                   </div>
                   <div className="icon-part">
                    <RiServiceFill/> 
                   <li> Service</li>
                   </div>
                   <div className="icon-part">
                    <FiUser/> 
                   <li>Students</li>
                   </div>
                  
                </ul>
                <div className="center">V-Ex Tech. Solution</div>
                <div className="right">
                    <AiOutlineSearch/>
                    <MdOutlineNotificationsNone/>
                  
                        <AiOutlineMenuUnfold/>
                       
                </div>
            </div>
        </header>
    )
    
    
};

export default Header;