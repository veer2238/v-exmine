import "./Banner.scss";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import Product from "./Json";

const Banner = (props) => {
    const responsive = {
        superLargeDesktop: {
          // the naming can be any, depends on you.
          breakpoint: { max: 4000, min: 3000 },
          items: 11
        },
        desktop: {
          breakpoint: { max: 3000, min: 1024 },
          items: 9
        },
        tablet: {
          breakpoint: { max: 1024, min: 464 },
          items: 4
        },
        mobile: {
          breakpoint: { max: 464, min: 0 },
          items: 3
        }
      };
    return <div className="main">

        <div className="student">Our Students</div>
    <Carousel responsive={responsive}
     autoPlay={props.deviceType !== "mobile" ? true : false}
     autoPlaySpeed={2000}
     removeArrowOnDeviceType={["tablet", "mobile"]}
     swipeable={true}
  draggable={false}

  
     >

        {Product.map((Item)=>{
            return(
                <>
             <div key={Item.id} className="image">

                
             
              <img src={Item.avatar_url}  height={"100%"} width={"100%"} className="border"/>
              <div className="name">{Item.login}</div>
              <div className="position">-{Item.gravatar_id}-</div>
           
              
              </div>

             

              </>
             
             
            )

        })}

     

 
 
</Carousel>
   

    </div>
}

export default Banner;
