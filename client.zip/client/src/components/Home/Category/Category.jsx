import "./Category.scss";


const Category = () => {
    return <div>
  
    </div>;
};

export default Category;
