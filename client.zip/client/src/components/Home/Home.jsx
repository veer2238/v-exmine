import Products from "../Products/Products";
import Banner from "./Banner/Banner";
import Category from "./Category/Category";
import "./Home.scss";
const Home = () => {
    return <div>

        <Banner />
      
        
         

    </div>;
};

export default Home;
