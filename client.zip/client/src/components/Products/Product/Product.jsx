import "./Product.scss";

const Product = () => {
    return <div>

        product

 
   


</div>;
};

export default Product;
