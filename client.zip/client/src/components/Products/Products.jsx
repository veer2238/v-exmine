
import "./Products.scss";


const Products = () => {

    return (
      <div>product</div>
    )
};

export default Products;
