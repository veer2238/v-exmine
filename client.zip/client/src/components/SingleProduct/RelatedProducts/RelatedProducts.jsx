const RelatedProducts = () => {
    return <div>Related Products</div>;
};

export default RelatedProducts;
