import React from 'react'
import "./SingleProduct.scss";

const SingleProduct = () => {
  return (
    <div>SingleProduct</div>
  )
}

export default SingleProduct