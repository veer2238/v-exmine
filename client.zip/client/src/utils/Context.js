import React,{Children,useState, createContext} from 'react'

export const Context = createContext();

const AppContext = ({children}) =>{
    return(
        <Context.Provider>
            {children}
        </Context.Provider>
    )
}

export default AppContext;